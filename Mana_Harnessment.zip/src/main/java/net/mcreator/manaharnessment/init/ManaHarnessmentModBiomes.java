
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.manaharnessment.init;

import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.level.biome.Biome;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.manaharnessment.world.biome.ManaforestBiome;
import net.mcreator.manaharnessment.world.biome.GodRealmBiomeBiome;
import net.mcreator.manaharnessment.ManaHarnessmentMod;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ManaHarnessmentModBiomes {
	private static final List<Biome> REGISTRY = new ArrayList<>();
	public static Biome MANAFOREST = register("manaforest", ManaforestBiome.createBiome());
	public static Biome GOD_REALM_BIOME = register("god_realm_biome", GodRealmBiomeBiome.createBiome());

	private static Biome register(String registryname, Biome biome) {
		REGISTRY.add(biome.setRegistryName(new ResourceLocation(ManaHarnessmentMod.MODID, registryname)));
		return biome;
	}

	@SubscribeEvent
	public static void registerBiomes(RegistryEvent.Register<Biome> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Biome[0]));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			ManaforestBiome.init();
			GodRealmBiomeBiome.init();
		});
	}
}
