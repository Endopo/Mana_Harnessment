
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.manaharnessment.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.manaharnessment.client.renderer.MoongodRenderer;
import net.mcreator.manaharnessment.client.renderer.HeimdallProtectorOfTheGodsRenderer;
import net.mcreator.manaharnessment.client.renderer.DarkmagesRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ManaHarnessmentModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(ManaHarnessmentModEntities.DARKMAGES, DarkmagesRenderer::new);
		event.registerEntityRenderer(ManaHarnessmentModEntities.WAND, ThrownItemRenderer::new);
		event.registerEntityRenderer(ManaHarnessmentModEntities.HEIMDALL_PROTECTOR_OF_THE_GODS, HeimdallProtectorOfTheGodsRenderer::new);
		event.registerEntityRenderer(ManaHarnessmentModEntities.MOONGOD, MoongodRenderer::new);
		event.registerEntityRenderer(ManaHarnessmentModEntities.MOON_STAFF, ThrownItemRenderer::new);
	}
}
