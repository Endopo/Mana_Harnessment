
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.manaharnessment.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.manaharnessment.item.WandItem;
import net.mcreator.manaharnessment.item.MoonStaffItem;
import net.mcreator.manaharnessment.item.MananaItem;
import net.mcreator.manaharnessment.item.ManadustItem;
import net.mcreator.manaharnessment.item.Mana_ToolsSwordItem;
import net.mcreator.manaharnessment.item.Mana_ToolsShovelItem;
import net.mcreator.manaharnessment.item.Mana_ToolsPickaxeItem;
import net.mcreator.manaharnessment.item.Mana_ToolsHoeItem;
import net.mcreator.manaharnessment.item.Mana_ToolsAxeItem;
import net.mcreator.manaharnessment.item.ManaCrystalsItem;
import net.mcreator.manaharnessment.item.ManaCrystalArmorItem;
import net.mcreator.manaharnessment.item.GodRealmItem;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ManaHarnessmentModItems {
	private static final List<Item> REGISTRY = new ArrayList<>();
	public static final Item MANADIRT = register(ManaHarnessmentModBlocks.MANADIRT, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item MANALOG = register(ManaHarnessmentModBlocks.MANALOG, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item MANALEAVE = register(ManaHarnessmentModBlocks.MANALEAVE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item DARKMAGES = register(
			new SpawnEggItem(ManaHarnessmentModEntities.DARKMAGES, -16777216, -13421773, new Item.Properties().tab(CreativeModeTab.TAB_MISC))
					.setRegistryName("darkmages_spawn_egg"));
	public static final Item MANAORE = register(ManaHarnessmentModBlocks.MANAORE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item MANA_CRYSTALS = register(new ManaCrystalsItem());
	public static final Item WAND = register(new WandItem());
	public static final Item MANANA = register(new MananaItem());
	public static final Item MANAGRASS = register(ManaHarnessmentModBlocks.MANAGRASS, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item MANASAND = register(ManaHarnessmentModBlocks.MANASAND, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item MANA_PLANKS = register(ManaHarnessmentModBlocks.MANA_PLANKS, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item MANA_CRYSTAL_ARMOR_HELMET = register(new ManaCrystalArmorItem.Helmet());
	public static final Item MANA_CRYSTAL_ARMOR_CHESTPLATE = register(new ManaCrystalArmorItem.Chestplate());
	public static final Item MANA_CRYSTAL_ARMOR_LEGGINGS = register(new ManaCrystalArmorItem.Leggings());
	public static final Item MANA_CRYSTAL_ARMOR_BOOTS = register(new ManaCrystalArmorItem.Boots());
	public static final Item MANAFLOWER = register(ManaHarnessmentModBlocks.MANAFLOWER, CreativeModeTab.TAB_DECORATIONS);
	public static final Item MANADUST = register(new ManadustItem());
	public static final Item PORTALFRAMETOTHEGODS = register(ManaHarnessmentModBlocks.PORTALFRAMETOTHEGODS, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item GODGRASS = register(ManaHarnessmentModBlocks.GODGRASS, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item GODDIRT = register(ManaHarnessmentModBlocks.GODDIRT, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item HEIMDALL_PROTECTOR_OF_THE_GODS = register(new SpawnEggItem(ManaHarnessmentModEntities.HEIMDALL_PROTECTOR_OF_THE_GODS,
			-26368, -1, new Item.Properties().tab(CreativeModeTab.TAB_MISC)).setRegistryName("heimdall_protector_of_the_gods_spawn_egg"));
	public static final Item GOD_REALM = register(new GodRealmItem());
	public static final Item MANA_TOOLS_PICKAXE = register(new Mana_ToolsPickaxeItem());
	public static final Item MANA_TOOLS_AXE = register(new Mana_ToolsAxeItem());
	public static final Item MANA_TOOLS_SWORD = register(new Mana_ToolsSwordItem());
	public static final Item MANA_TOOLS_SHOVEL = register(new Mana_ToolsShovelItem());
	public static final Item MANA_TOOLS_HOE = register(new Mana_ToolsHoeItem());
	public static final Item MOONGOD = register(
			new SpawnEggItem(ManaHarnessmentModEntities.MOONGOD, -16777216, -1, new Item.Properties().tab(CreativeModeTab.TAB_MISC))
					.setRegistryName("moongod_spawn_egg"));
	public static final Item MOON_STAFF = register(new MoonStaffItem());

	private static Item register(Item item) {
		REGISTRY.add(item);
		return item;
	}

	private static Item register(Block block, CreativeModeTab tab) {
		return register(new BlockItem(block, new Item.Properties().tab(tab)).setRegistryName(block.getRegistryName()));
	}

	@SubscribeEvent
	public static void registerItems(RegistryEvent.Register<Item> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Item[0]));
	}
}
