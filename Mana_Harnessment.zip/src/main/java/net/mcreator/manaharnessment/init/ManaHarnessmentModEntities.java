
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.manaharnessment.init;

import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.manaharnessment.entity.WandEntity;
import net.mcreator.manaharnessment.entity.MoongodEntity;
import net.mcreator.manaharnessment.entity.MoonStaffEntity;
import net.mcreator.manaharnessment.entity.HeimdallProtectorOfTheGodsEntity;
import net.mcreator.manaharnessment.entity.DarkmagesEntity;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ManaHarnessmentModEntities {
	private static final List<EntityType<?>> REGISTRY = new ArrayList<>();
	public static final EntityType<DarkmagesEntity> DARKMAGES = register("darkmages",
			EntityType.Builder.<DarkmagesEntity>of(DarkmagesEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(DarkmagesEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final EntityType<WandEntity> WAND = register("entitybulletwand",
			EntityType.Builder.<WandEntity>of(WandEntity::new, MobCategory.MISC).setCustomClientFactory(WandEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final EntityType<HeimdallProtectorOfTheGodsEntity> HEIMDALL_PROTECTOR_OF_THE_GODS = register("heimdall_protector_of_the_gods",
			EntityType.Builder.<HeimdallProtectorOfTheGodsEntity>of(HeimdallProtectorOfTheGodsEntity::new, MobCategory.CREATURE)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)
					.setCustomClientFactory(HeimdallProtectorOfTheGodsEntity::new).sized(0.6f, 1.8f));
	public static final EntityType<MoongodEntity> MOONGOD = register("moongod",
			EntityType.Builder.<MoongodEntity>of(MoongodEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(MoongodEntity::new).sized(0.6f, 1.8f));
	public static final EntityType<MoonStaffEntity> MOON_STAFF = register("entitybulletmoon_staff",
			EntityType.Builder.<MoonStaffEntity>of(MoonStaffEntity::new, MobCategory.MISC).setCustomClientFactory(MoonStaffEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	private static <T extends Entity> EntityType<T> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		EntityType<T> entityType = (EntityType<T>) entityTypeBuilder.build(registryname).setRegistryName(registryname);
		REGISTRY.add(entityType);
		return entityType;
	}

	@SubscribeEvent
	public static void registerEntities(RegistryEvent.Register<EntityType<?>> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new EntityType[0]));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			DarkmagesEntity.init();
			HeimdallProtectorOfTheGodsEntity.init();
			MoongodEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(DARKMAGES, DarkmagesEntity.createAttributes().build());
		event.put(HEIMDALL_PROTECTOR_OF_THE_GODS, HeimdallProtectorOfTheGodsEntity.createAttributes().build());
		event.put(MOONGOD, MoongodEntity.createAttributes().build());
	}
}
