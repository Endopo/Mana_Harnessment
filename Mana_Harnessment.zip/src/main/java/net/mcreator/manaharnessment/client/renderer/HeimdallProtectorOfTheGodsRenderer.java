package net.mcreator.manaharnessment.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import net.mcreator.manaharnessment.entity.HeimdallProtectorOfTheGodsEntity;

public class HeimdallProtectorOfTheGodsRenderer
		extends
			HumanoidMobRenderer<HeimdallProtectorOfTheGodsEntity, HumanoidModel<HeimdallProtectorOfTheGodsEntity>> {
	public HeimdallProtectorOfTheGodsRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
				new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR))));
	}

	@Override
	public ResourceLocation getTextureLocation(HeimdallProtectorOfTheGodsEntity entity) {
		return new ResourceLocation("mana_harnessment:textures/2021_08_08_heimdall-in-a-suit-nordic-mythology-18615127.png");
	}
}
